const mongoose = require('mongoose');

const MONGO_URI = 'mongodb+srv://Misha110208:Misha110208@aviamarket.7o9kplj.mongodb.net/tickets?retryWrites=true&w=majority&appName=aviamarket';

async function createTestBooking() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✓ Подключено к MongoDB Atlas\n');

    const User = mongoose.model('User', new mongoose.Schema({}, { strict: false }));
    const Booking = mongoose.model('Booking', new mongoose.Schema({}, { strict: false }));

    const user = await User.findOne({ email: 'test@test.com' });
    if (!user) {
      console.log('❌ Пользователь не найден');
      await mongoose.disconnect();
      return;
    }

    console.log(`✓ Пользователь найден: ${user.email} (${user._id})\n`);

    // Создаем тестовое бронирование
    const testBooking = new Booking({
      user: user._id,
      from: 'Москва (SVO)',
      to: 'Санкт-Петербург (LED)',
      departureDate: new Date('2025-12-15'),
      returnDate: null,
      isRoundTrip: false,
      flightNumber: 'SU 1234',
      departTime: '10:00',
      arriveTime: '11:30',
      passengers: [{
        fullName: user.fullName,
        dateOfBirth: '1990-01-01',
        gender: 'Мужской',
        passport: '1234567890',
      }],
      providerBookingId: `test-${Date.now()}`,
      bookingStatus: 'reserved',
      provider: 'test',
      payment: {
        paymentStatus: 'pending',
        amount: 5000,
        currency: 'RUB',
      },
      seat: '12A',
      gate: 'B5',
      boardingTime: '09:30',
    });

    await testBooking.save();
    
    console.log('✅ Тестовое бронирование создано!');
    console.log(`   ID: ${testBooking._id}`);
    console.log(`   Маршрут: ${testBooking.from} → ${testBooking.to}`);
    console.log(`   Рейс: ${testBooking.flightNumber}`);
    console.log(`   Дата: ${testBooking.departureDate.toLocaleDateString('ru-RU')}`);
    console.log(`   Цена: ${testBooking.payment.amount} ${testBooking.payment.currency}`);
    console.log('');

    // Проверяем
    const bookings = await Booking.find({ user: user._id });
    console.log(`✓ Всего бронирований пользователя: ${bookings.length}\n`);

    await mongoose.disconnect();
    console.log('✓ Готово!');

  } catch (error) {
    console.error('❌ Ошибка:', error.message);
    process.exit(1);
  }
}

createTestBooking();
