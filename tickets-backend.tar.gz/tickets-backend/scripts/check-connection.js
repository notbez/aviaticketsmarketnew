const mongoose = require('mongoose');

const MONGO_URI = 'mongodb+srv://Misha110208:Misha110208@aviamarket.7o9kplj.mongodb.net/tickets?retryWrites=true&w=majority&appName=aviamarket';

async function checkConnection() {
  console.log('🔍 ПРОВЕРКА ПОДКЛЮЧЕНИЯ К MONGODB');
  console.log('═══════════════════════════════════════\n');

  try {
    console.log('1️⃣ Подключение к MongoDB Atlas...');
    await mongoose.connect(MONGO_URI);
    console.log('✅ Подключено успешно\n');

    console.log('2️⃣ Информация о подключении:');
    console.log(`   База данных: ${mongoose.connection.db.databaseName}`);
    console.log(`   Хост: ${mongoose.connection.host}`);
    console.log('');

    console.log('3️⃣ Список коллекций в базе "tickets":');
    const collections = await mongoose.connection.db.listCollections().toArray();
    
    if (collections.length === 0) {
      console.log('   ⚠️  Коллекций нет (база пустая)');
    } else {
      for (const coll of collections) {
        const count = await mongoose.connection.db.collection(coll.name).countDocuments();
        console.log(`   - ${coll.name} (документов: ${count})`);
      }
    }
    console.log('');

    console.log('4️⃣ Проверка пользователя test@test.com:');
    const User = mongoose.model('User', new mongoose.Schema({}, { strict: false }));
    const user = await User.findOne({ email: 'test@test.com' });
    
    if (user) {
      console.log('   ✅ Пользователь найден');
      console.log(`   ID: ${user._id}`);
      console.log(`   Имя: ${user.fullName}`);
      console.log(`   Email: ${user.email}`);
    } else {
      console.log('   ❌ Пользователь НЕ найден');
    }
    console.log('');

    console.log('5️⃣ Проверка бронирований:');
    const Booking = mongoose.model('Booking', new mongoose.Schema({}, { strict: false }));
    const bookings = await Booking.find({});
    console.log(`   Всего бронирований: ${bookings.length}`);
    
    if (user && bookings.length > 0) {
      const userBookings = bookings.filter(b => b.user.toString() === user._id.toString());
      console.log(`   Бронирований пользователя: ${userBookings.length}`);
    }
    console.log('');

    await mongoose.disconnect();
    
    console.log('═══════════════════════════════════════');
    console.log('✅ ПРОВЕРКА ЗАВЕРШЕНА');
    console.log('═══════════════════════════════════════\n');

    console.log('📋 ВЫВОД:');
    console.log(`   База данных: tickets`);
    console.log(`   Коллекций: ${collections.length}`);
    console.log(`   Пользователь: ${user ? '✅' : '❌'}`);
    console.log(`   Бронирований: ${bookings.length}`);

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    process.exit(1);
  }
}

checkConnection();
