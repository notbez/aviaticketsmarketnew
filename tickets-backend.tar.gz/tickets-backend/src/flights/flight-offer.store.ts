import { v4 as uuid } from 'uuid';
import { FlightOffer } from './flight-offer.entity';

class FlightOfferStore {
  private store = new Map<string, FlightOffer>();

  save(raw: any, price: number, currency: string): FlightOffer {
    const offer: FlightOffer = {
      id: uuid(),
      provider: 'onelya',
      providerRaw: raw,
      price,
      currency,
      createdAt: new Date().toISOString(),
    };

    this.store.set(offer.id, offer);
    return offer;
  }

  get(id: string): FlightOffer | undefined {
    return this.store.get(id);
  }
}

export const flightOfferStore = new FlightOfferStore();