export const AIRPORTS = [
      { code: 'SVO', city: 'Москва (Шереметьево)' },
      { code: 'DME', city: 'Москва (Домодедово)' },
      { code: 'VKO', city: 'Москва (Внуково)' },
      { code: 'LED', city: 'Санкт-Петербург (Пулково)' },
      { code: 'AER', city: 'Сочи (Адлер)' },
      { code: 'KZN', city: 'Казань' },
      { code: 'SVX', city: 'Екатеринбург (Кольцово)' },
      { code: 'OVB', city: 'Новосибирск (Толмачёво)' },
    ];