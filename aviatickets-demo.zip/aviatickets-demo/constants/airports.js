export const AIRPORTS = [
      { code: 'SVO', city: 'Moscow (SVO)' },
      { code: 'DME', city: 'Moscow (DME)' },
      { code: 'LED', city: 'Saint Petersburg (LED)' },
      { code: 'KZN', city: 'Kazan (KZN)' },
      { code: 'SVX', city: 'Yekaterinburg (SVX)' },
      { code: 'KGD', city: 'Kaliningrad (KGD)' },
    ];